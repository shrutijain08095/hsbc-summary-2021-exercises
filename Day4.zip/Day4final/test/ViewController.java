package com.demo.test;

import java.util.Scanner;

import com.demo.beans.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class ViewController {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		EmployeeService service = new EmployeeServiceImpl();
		int controllerOption = 0;
		do {
			System.out.println("Enter options:-");
			System.out.println("1: Store employee 2: Find employee by id 3: Find All employees 4: Update Name 5: Update Salary 0: Exit");
			controllerOption = scan.nextInt();
			switch(controllerOption) {
			case 1: 
				System.out.println("--- Enter employee details ------");
				Employee emp = new Employee();
				System.out.println("Enter id");
				emp.setId(scan.nextInt()); // instead of int id = scan.nextInt(); emp.setId(id);
				System.out.println("Enter name");
				emp.setName(scan.next());
				System.out.println("Enter salary");
				emp.setSalary(scan.nextDouble());
				service.store(emp);
				System.out.println("Successfully stored.....");
				System.out.println("---------------------------------");
				break;
			case 2: 
				System.out.println("enter details of the employee to be updated");
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter id");
				int id1=sc.nextInt();
				Employee e1=service.findEmployee(id1);
				System.out.println(e1);
				
				
				break;
				
				
				
			case 3: 
				Employee[] employees = service.findAllEmployees();
				for(Employee e : employees) {
					System.out.println("Hello "+e.getName()+", Your salary is: "+e.getSalary()+" and id is : "+e.getId());
				}
				break;
			case 4: 
				Scanner sc2=new Scanner(System.in);
				
				System.out.println("for salary to be updated ");
				System.out.println("enter id");
				
				int id2=sc2.nextInt();
				System.out.println("enter salary");
				double salary2=sc2.nextDouble();
				service.updateSalary(id2,salary2);
				
				
				break;
			case 5: 
				break;
			}
		} while(controllerOption != 0);
		scan.close();
	}
	
}