package com.demo.service;

import com.demo.beans.Employee;
import com.demo.dao.EmployeeDao;
import com.demo.dao.EmployeeDaoArrayImpl;


	

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDao dao = null;
	public EmployeeServiceImpl() {
		// this is wrong approach we need to use factory pattern
		dao = new EmployeeDaoArrayImpl();
	}

	public void store(Employee employee) {
		dao.save(employee);
	}

	public Employee findEmployee(int id) {
		return dao.fetchEmployeeById(id);
		
		
		
	}

	public Employee[] findAllEmployees() {
		return dao.findAllEmployees();
	}

	public void updateSalary(int id2, double salary2) {
		dao.updateEmployee(new Employee(id2,salary2));
		
		
	}

	public void updateName(int id, String name) {
			
	}

}