package com.demo.dao;

import com.demo.beans.Employee;

import java.util.*;

public class EmployeeDaoArrayImpl implements EmployeeDao {

	private static Employee[] employeeDb = new Employee[10];
	private static int arrayIndexCounter = 0;
	public void save(Employee employee) {
		employeeDb[arrayIndexCounter] = employee;
		arrayIndexCounter++;
	}
	public Employee fetchEmployeeById(int id) {
		for(Employee e:employeeDb) {
			if(e.getId()==id) {
				return e;
			}
		}
		return null;
	}
	public Employee[] findAllEmployees() {
		Employee[] tempDb = new Employee[arrayIndexCounter];
		for(int index = 0; index < arrayIndexCounter; index++) {
			tempDb[index] = employeeDb[index];
		}
		return tempDb;
	}
	
		
	
	public void updateEmployee(Employee employee) {
			
			
	}
	
	
	
	
	
}