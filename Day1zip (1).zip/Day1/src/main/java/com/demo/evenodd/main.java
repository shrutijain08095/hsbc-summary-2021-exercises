package com.demo.evenodd;
import java.util.*;

public class main {
	public void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a,b;
		a=sc.nextInt();
		b=sc.nextInt();
		even(a,b);
		odd(a,b);
		
		
	}
	
	public void even(int a,int b) {
		for(int i=a; i<=b; i++) {
			if(i%2==0) {
				System.out.println(i);
				
			}
		}
	}
	
	public void odd(int a,int b) {
		for(int i=a; i<=b; i++) {
			if(i%2==1) {
				System.out.println(i);
				
			}
		}
	}
	
}
