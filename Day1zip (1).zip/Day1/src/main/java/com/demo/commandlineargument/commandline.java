package com.demo.commandlineargument;

public class commandline {

	public static void main(String[] args) {
		
		for(String s : args) {
			System.out.println(s);
		}
	}

}
