package com.demo.beans;

public class AutomobileUI {
	public static void displayColour(Car car) {
		car.getMilaege();
		car.getcolour();
	}

}
