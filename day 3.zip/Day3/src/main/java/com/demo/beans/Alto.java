package com.demo.beans;

public class Alto extends Car{
	public void getcolour() {
		System.out.println("Color of car alto is white");
	}
}
