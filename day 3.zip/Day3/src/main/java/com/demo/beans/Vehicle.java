package com.demo.beans;

public interface Vehicle {
	public void getMilaege();
	public void getcolour();
	

}
