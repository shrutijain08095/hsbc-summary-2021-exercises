package com.demo.beans;

public class SelectVehicle {
	public void main (String[] args) {
		Alto alt=new Alto();
		AutomobileUI.displayColour(alt);
		
	}
}
