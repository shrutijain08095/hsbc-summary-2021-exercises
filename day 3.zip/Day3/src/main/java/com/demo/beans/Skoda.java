package com.demo.beans;

public class Skoda extends Car{
	public void getcolour() {
		System.out.println("the clour of car Skoda is black");
		
		
	}

}
