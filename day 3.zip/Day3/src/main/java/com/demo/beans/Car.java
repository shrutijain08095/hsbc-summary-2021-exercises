package com.demo.beans;

public abstract class  Car implements Vehicle {
	public void getMilaege() {
		System.out.println("in class car");
		
	}
	
	

}
