package Shapes;

public class Sphere extends Figures{

	public double getArea(int radius) {
		
		return (4*3.14*radius*radius);
		
	

		
	}
	

}
