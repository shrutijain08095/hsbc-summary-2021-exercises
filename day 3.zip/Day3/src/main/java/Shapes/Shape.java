package Shapes;

public interface Shape {
	public double getArea(int radius);

}
