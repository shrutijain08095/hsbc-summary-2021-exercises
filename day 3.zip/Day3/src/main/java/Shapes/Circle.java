package Shapes;

public class Circle extends Figures{

	public double getArea(int radius) {
		
		return (3.14*radius*radius);
	}
	
	

}
