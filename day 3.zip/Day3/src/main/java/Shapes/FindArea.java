package Shapes;
import java.util.*;

public class FindArea {
	public static void findArea(Figures figure) {
		Scanner sc=new Scanner(System.in);
		int rad=sc.nextInt();
		
		System.out.println(figure.getArea( rad));
		
	}

}
