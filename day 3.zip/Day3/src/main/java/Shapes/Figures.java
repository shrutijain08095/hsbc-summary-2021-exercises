package Shapes;

public abstract class Figures implements Shape {
	

}
