package Shapes;

import java.util.Scanner;

public class MainMethod {
	public  void main(String[] args) {
		Circle c = new Circle();
		
		FindArea.findArea(c);
		
	}

}
