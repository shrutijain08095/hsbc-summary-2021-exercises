package com.demo.service;

import com.demo.dao.EmployeeDao;
import com.demo.dao.EmployeeDaoArrayImpl;

public class FactoryPattern1 {
	public static EmployeeService getServiceInstance(){
		
		return new EmployeeServiceImpl();

	}
}