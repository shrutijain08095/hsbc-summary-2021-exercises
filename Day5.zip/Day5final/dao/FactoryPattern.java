package com.demo.dao;

public class FactoryPattern {
	public static EmployeeDao getDaoInstance(){
		
		return new EmployeeDaoArrayImpl();
		
		
	}

}
